<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&family=Open+Sans&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="style.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
  </head>
  <body class="container big-container">
    <header class="border-bottom">
      <img src="img/6819196.png" alt="" />
      <div><?php echo $_GET["name"]?></div>
      <div><?php echo $_GET["born"]?></div>
      <div><?php echo $_GET["nationality"]?></div>

      <?php echo $_GET["description"]?>
      <div>
        Soy <?php echo $_GET["ocupation"]?>
      </div>
    </header>
    <main>
      <div id="main-container">
        <div class="item item-1 border-end">
          <h2>IDIOMAS</h2>
          <ul>
            <li>Ingles: <?php echo $_GET["ingles"]?></li>
          </ul>
        </div>
        <div class="item item-2 border-end">
          <h2>FORMACION</h2>
          <ul>
            <?php 
            foreach($_GET["lenguajes"] as $op){
              echo "Lenguaje: $op <br>";
            }
            ?>
          </ul>
        </div>
        <div class="item item-3">
          <h2>EXPERENCIA LABORAL</h2>
          <ul>
            <li>
              <h4><?php 
                echo $_GET["aptitudes"]?></h4>

              <h4><?php foreach( $_GET["hab"] as $op){
                  echo "Aptitud: $op <br>";
              }
                
                ?></h4>
            </li>
          </ul>
        </div>
      </div>
    </main>
    <footer class="border-top">
      <ul id="links">
        <li><img src="img/github.svg" alt="github" /> GebUCSP</li>
        <li>
          <img src="img/envelope.svg" alt="email" />
          <?php echo $_GET["email"]?>
        </li>
        <li><img src="img/telephone.svg" alt="phone" /> <?php echo $_GET["phone"]?></li>
      </ul>
    </footer>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
